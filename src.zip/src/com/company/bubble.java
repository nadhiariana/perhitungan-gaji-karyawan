package com.company;
import java.util.Scanner;

public class bubble {
    public static void main(String[]args) {
        int jumlah,i,j, swap;
        Scanner scan = new Scanner(System.in);
        System.out.print("Masukan jumlah element integer : ");
        jumlah = scan.nextInt();
        int array[] = new int[jumlah];
        System.out.println("\nMasukan nilai " + jumlah+" element integer");
        System.out.println("===========================================");
        for(i=0; i<jumlah;i++) {
            System.out.print("Nilai Ke- " + (i+1)+" = ");
            array[i]=scan.nextInt();
        }

        for(i=0; i<(jumlah-1);i++) {
            for(j=0;j<jumlah-i-1;j++) {
                if (array[j] > array[j+1]) {
                    swap = array[j];
                    array[j] = array[j+1];
                    array[j+1]=swap;
                }
            }
        }
        System.out.println("\n\nBilangan setelah diurutkan :");
        for(i=0;i<jumlah; i++)
            System.out.print(array[i] +" ");
    }
}