package com.company;

public class voidFunction {
    static void methodHello(int a){
        int i;
        for(i=0;i<a;i++){
            System.out.print("Hello World\n");
        }
    }
    public static void main(String[] args){
        methodHello(3);
    }
}
