package com.company;

public class contohDo {
    public static void main(String[] args) {
        int i = 10;
        do {
            System.out.println("Belajar Java itu Menyenangkan");
            i++;
        }
        while (i>5);
    }
}
