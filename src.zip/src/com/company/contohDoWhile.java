package com.company;

public class contohDoWhile {
    public static void main(String[] args) {
        int angka=1;
        do{
            System.out.println("Bilangan : "+angka);
        }while (angka>=6);
    }
}
