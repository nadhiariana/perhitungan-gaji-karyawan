package com.company;
import java.util.Scanner;

public class forum_method {
    public static void main(String[] args){
        hitungPangkat(); //memanggil method hitungPangkat()
    }
    public static void hitungPangkat(){
        Scanner input = new Scanner(System.in); //deklarasi scanner
        System.out.print("Masukkan nilai x : "); //mencetak perintah input
        int a = input.nextInt(); //menampung inputan dengan tipe data integer
        int pangkat = (int) Math.pow(2,a); //menghitung hasil 2 pangkat x
        sumPangkat(pangkat); //memanggil method sumPangkat()
    }
    public static void sumPangkat(int pangkat){
        String digit = String.valueOf(pangkat);
        int nomor = 0; //deklarasi variabel nomor=0 dengan tipe integer
        for(int i=0; i<digit.length(); i++){
            int j=i+1;
            nomor = nomor + Integer.parseInt(digit.substring(i,j));//menjumlahkan tiap angka pangkat
        }
        System.out.println("Jawabannya : "+nomor+"."); //mencetak hasil penjumlahan angka pangkat
    }
}
