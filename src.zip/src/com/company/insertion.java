package com.company;
import java.util.Scanner;

public class insertion{
    public static void sort(int[] list){
        for(int i = 1 ; i < list.length ; i++) {
            int currentElement = list[i];
            int k;
            for (k = i - 1; k >= 0 && list[k] > currentElement; k--) {
                list[k + 1] = list[k];
            }
            list[k + 1] = currentElement;
        }
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner( System.in );
        System.out.println("Insertion Sort Test\n");
        int n, i;
        System.out.println("Masukan jumlah element integer");
        n = scan.nextInt();
        int arr[] = new int[ n ];
        System.out.println("\nMasukan nilai "+ n +" element integer");
        for (i = 0; i < n; i++)
            arr[i] = scan.nextInt();
            sort(arr);
            System.out.println("\nElement integer setelah diurutkan ");
        for (i = 0; i < n; i++)
            System.out.print(arr[i]+" ");
            System.out.println();
    }
}

