package com.company;

import java.util.Scanner;

public class Selection {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Masukkan Angka antara 1 - 100 : ");
        int angka = Integer.parseInt(input.nextLine());

        if (angka >= 1 && angka <= 100) { // Kondisi apabila angka yang diinput berada di range 1 - 100
            if (angka % 2 == 0) { // Kondisi apabila angka yang diinput merupakan angka genap
                if (angka <= 5) { // Kondisi apabila angka yang diinput berada di range 2 - 5
                    System.out.println("Tidak AJAIB");
                }
                else if (angka <= 20) { // Kondisi apabila angka yang diinput berada di range 6 - 20
                    System.out.println("AJAIB");
                }
                else { // Kondisi apabila angka yang diinput berada di range 21 - 100
                    System.out.println("Tidak AJAIB");
                }
            }
            else { // Kondisi apabila angka yang diinput merupakan angka ganjil
                System.out.println("AJAIB");
            }
        }
        else { // Kondisi apabila angka yang diinput < 1 atau > 100
            System.out.println("Angka yang anda masukkan tidak berada dalam range 1 - 100");
        }
    }
}
