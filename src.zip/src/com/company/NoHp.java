package com.company;
import java.util.Scanner;

public class NoHp {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Silahkan masukkan nomor handphone Anda: ");
        String hp = input.next();
        System.out.print("\nNomor yang anda masukkan : \n");
        int nomor = 0;
        for(int a = 0; a < hp.length(); a++){
            int b = a + 1;
            nomor = nomor + Integer.parseInt(hp.substring(a,b));
            System.out.print(hp.substring(a,b) + "+");
        }
        System.out.println();
        System.out.print("\nTotalnya : " + nomor);
    }
}

