package com.company;

import java.util.Scanner;

public class OperatorTernary {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Masukkan nilai : ");
        int angka = input.nextInt();
        System.out.println(angka > 75 ? "Lulus" : "Gagal");
    }
}
