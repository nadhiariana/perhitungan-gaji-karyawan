package com.company;

import java.util.Scanner;
import java.text.DecimalFormat;

public class TugasKelompok {

    public static void main(String[] args) {
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        Scanner input = new Scanner(System.in);

        System.out.println("Selamat Siang . . .");
        System.out.print("Pesan untuk berapa orang\t: ");
        int JumlahPemesan = input.nextInt();
        System.out.print("Pesanan Atas Nama\t\t\t: ");
        input.nextLine();
        String nama = input.nextLine();

        System.out.println("\nMenu Spesial Hari ini");
        System.out.println("=====================================");
        System.out.println("");
        System.out.println("1. Nasi Goreng Spesial            @ Rp.  9.999,99");
        System.out.println("2. Ayam Bakar Spesial             @ Rp. 12.345,67");
        System.out.println("3. Steak Sirloin Spesial          @ Rp. 21.108,40");
        System.out.println("4. Kwetiaw Siram Spesial          @ Rp. 13.579,13");
        System.out.println("5. Kambing Guling Spesial         @ Rp. 98.765,43");
        System.out.println("");


        System.out.println("Pesanan Anda [batas pesanan 0-10 porsi]");
        System.out.print("1. Nasi Goreng Spesial     : ");
        int Nasi = input.nextInt();
        System.out.print("2. Ayam Bakar Spesial      : ");
        int AyamBakar = input.nextInt();
        System.out.print("3. Steak Sirloin Spesial   : ");
        int Sirloin = input.nextInt();
        System.out.print("4. Kwetiaw Siram Spesial   : ");
        int kwetiaw = input.nextInt();
        System.out.print("5. Kambing Guling Spesial  : ");
        int kambing = input.nextInt();

        System.out.println("");
        System.out.println("Selamat Menikmati Makanan Anda ...");

        System.out.println("\nPembelian");
        System.out.println("");
        double totalnasi = Nasi * 9999.99;
        double totalayam = AyamBakar * 12345.67;
        double totalsirloin = Sirloin * 21108.40;
        double totalkwetiaw = kwetiaw * 13579.13;
        double totalkambing = kambing * 98765.43;

        System.out.println("1. Nasi Goreng Spesial     " + Nasi + " porsi * Rp.  9.999,99\t = Rp." + decimalFormat.format(totalnasi));
        System.out.println("2. Ayam Bakar Spesial      " + AyamBakar + " porsi * Rp. 12.345,67\t = Rp." + decimalFormat.format(totalayam));
        System.out.println("3. Steak Sirloin Spesial   " + Sirloin + " porsi * Rp. 21.108,40\t = Rp." + decimalFormat.format(totalsirloin));
        System.out.println("4. Kwetiaw Siram Spesial   " + kwetiaw + " porsi * Rp. 13.579,13\t = Rp." + decimalFormat.format(totalkwetiaw));
        System.out.println("5. Kambing Guling Spesial  " + kambing + " porsi * Rp. 98.765,43\t = Rp." + decimalFormat.format(totalkambing));
        System.out.println("=====================================================================");
        System.out.println("");
        double totalpembelian = totalnasi + totalayam + totalsirloin + totalkwetiaw + totalkambing;
        System.out.println("Total pembelian\t\t\t\t\t\t= Rp." + decimalFormat.format(totalpembelian));
        double diskon = totalpembelian * 10 / 100;
        System.out.println("Disc. 10% (Masa Promosi)\t\t\t= Rp." + decimalFormat.format(diskon));
        System.out.println("=====================================================================");
        double totalafterdiskon = totalpembelian - diskon;
        System.out.println("Total Pembelian Setelah Diskon 10%\t= Rp." + decimalFormat.format(totalafterdiskon));
        double ratarata = totalafterdiskon / JumlahPemesan;
        System.out.println("Pembelian per orang (" + JumlahPemesan + ") orang\t\t= Rp." + decimalFormat.format(ratarata));
        System.out.println("");
        System.out.println("Terima Kasih Atas Kunjungan Anda");
        System.out.println("...tekan ENTER untuk keluar...");
        String enter = input.nextLine();

    }
}
