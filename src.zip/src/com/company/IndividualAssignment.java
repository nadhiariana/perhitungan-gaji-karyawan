package com.company;
import java.util.Scanner;

public class IndividualAssignment {
    public static void main(String[] args){
        System.out.print("**** Belajar Deret Aritmatika, Geometri dan menghitung Faktorial ****");
        Scanner input = new Scanner(System.in);
        Scanner inputNew = new Scanner(System.in);

        deret(input);
        boolean isloop = true;
        while(isloop){
            System.out.println("");
            System.out.print("\nAnda mau ulang (y/t) ? ");
            String inputan = inputNew.nextLine();
            if (inputan.equals("t") || inputan.equals("T")){
                System.out.print("===== Program berakhir =====");
                isloop=false;
            }else if(inputan.equals("y") || inputan.equals("Y")){
                deret(input);
            }else{
                System.out.print("===== Program berakhir =====");
                isloop=false;
            }
        }
    }
    static int validasiBanyak(int banyakAngka){
        if (banyakAngka < 2 || banyakAngka > 10) {
            return 0;
        }else{
            return 1;
        }
    }
    static int validasiBeda(int bedaAngka){
        if (bedaAngka < 2 || bedaAngka > 9) {
            return 0;
        }else{
            return 1;
        }
    }
    static int factorial(int f){
        if (f==0)
            return 1;
        else
            return(f*factorial(f-1));
    }
    public static void deret(Scanner input) {
        System.out.print("\nMasukkan banyak angka yang mau dicetak (antara 2 s/d 10)\t: ");
        int banyakAngka = input.nextInt();
        int resultValidasiBanyak = validasiBanyak(banyakAngka);

        if (resultValidasiBanyak==0){
            System.out.println("Banyaknya angka minimal 2 dan maksimal 10");
            System.out.println("===== Program berakhir =====");
            System.exit(0);
        }
        System.out.print("Masukkan beda masing-masing angka (antara 2 s/d 9)\t\t\t: ");
        int bedaAngka = input.nextInt();
        int resultValidasiBeda = validasiBeda(bedaAngka);
        if (resultValidasiBeda==0){
            System.out.println("Beda angka minimal 2 dan maksimal 9");
            System.out.println("===== Program berakhir =====");
            System.exit(0);
        }
        int i=1;
        System.out.println("\nDeret Aritmatika : ");
        for (int j=0; j<banyakAngka; j++){
            System.out.print(i+ " ");
            i = i+bedaAngka;
        }
        i=1;
        System.out.println("");
        System.out.println("\nDeret Geometri : ");
        for (int j=0; j<banyakAngka; j++){
            System.out.print(i+ " ");
            i = i*bedaAngka;
        }
        i=1;
        System.out.println("");
        System.out.println("\nFaktorial dari "+banyakAngka+" : ");
        int loop=banyakAngka;
        int faktorial=banyakAngka;
        int result=0;
        for (int j=1; j<loop; j++){
            System.out.print(banyakAngka + " * ");
            banyakAngka=banyakAngka-1;
            result=factorial(faktorial);
        }
        System.out.print("1 ");
        System.out.print(" = " + result);
    }
}
