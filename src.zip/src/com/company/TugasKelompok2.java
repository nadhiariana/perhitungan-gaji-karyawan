package com.company;

import java.util.Scanner;

public class TugasKelompok2{

    public static void main(String[] args) {
        boolean repeat = true;
        Scanner input = new Scanner(System.in);

        while (repeat) {
            System.out.print("Masukkan Nama Anda (1..25) : ");
            String nama = input.nextLine();
            while (nama.length()<1 || nama.length()>25) {
                System.out.println("karakter nama tidak boleh kosong atau lebih dari 25 karakter");
                System.out.print("Masukkan Nama Anda (1..25) : ");
                nama = input.nextLine();}

            System.out.print("Masukkan NIM Anda (harus 10 karakter) : ");
            String nim = input.nextLine();
            while (nim.length ()!=10){
                System.out.println("Jumlah NIM harus 10 karakter");
                System.out.print("Masukkan NIM Anda (harus 10 karakter) : ");
                nim = input.nextLine(); }

            System.out.println("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            System.out.println("");
            System.out.println("Registrasi Sukses.,");
            System.out.println("Selamat datang " + nama + " (NIM : " + nim + ").. ^^v");
            System.out.println("");
            System.out.println("Mari belajar macam-macam deret bilangan..");

            System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            Angka angka = new Angka();
            System.out.print("\nMasukkan Sembarang Angka (5..20) : ");
            int inputAngka= input.nextInt();
            System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            angka.setInput(inputAngka);
            if(angka.validate()){
                angka.getGanjil();
                angka.getGenap();
                angka.getFibonacci();
            } else {
                System.out.println(angka.getMessage());
            }
            System.out.print("\nAnda ingin mengulang [y/t] : ");
            String ulang = input.next();
            if (ulang.equals("y") || ulang.equals("Y")){
                repeat = true;
                nama = input.nextLine();
            } else {
                repeat = false;
            }
        }
        System.out.println("\nSampai jumpa..");
    }
}

class Angka {
    int input;
    String message;
    public Angka() {
    }
    public int getInput() {
        return input;
    }
    public void setInput(int input) {
        this.input = input;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public boolean validate(){
        if (input < 5 || input > 20){
            message = "Angka harus antara 5 sampai 20.";
            return false;
        } else {
            return true;
        }
    }
    public void getGenap(){
        String text = "";
        int count = 0;
        int i = 0;
        int total = 0;
        while(true){
            i++;
            if(i%2 == 0){
                text = text + String.valueOf(i) + " ";
                count++;
                total = total + i;
            }
            if(count == this.input){
                break;
            }
        }
        System.out.println("");
        System.out.println(String.valueOf(this.input) + " Bilangan genap :");
        System.out.println(text);
        System.out.println("Hasil penjumlahan = "+String.valueOf(total));
    }
    public void getGanjil(){
        String text = "";
        int count = 0;
        int i = 0;
        int total = 0;
        while(true){
            i++;
            if(i%2 != 0){
                text = text + String.valueOf(i) + " ";
                count++;
                total = total + i;
            }
            if(count == this.input){
                break;
            }
        }
        System.out.println("");
        System.out.println(String.valueOf(this.input) + " Bilangan ganjil :");
        System.out.println(text);
        System.out.println("Hasil penjumlahan = "+String.valueOf(total));
    }
    public void getFibonacci(){
        String text = "";
        int count = 0;
        int i = 0;
        int j1 = 0;
        int j2 = 0;
        int total = 0;
        while(true){
            if(i == 0){
                text = text + String.valueOf(i) + " ";
                i = i+1;
                j2 = i;
            } else {
                i = j1+j2;
                j1 = j2;
                j2 = i;
            }
            text = text + String.valueOf(i) + " ";
            total = total+i;
            count++;
            if(count == this.input){
                break;
            }
        }
        System.out.println("");
        System.out.println(String.valueOf(this.input) + " Bilangan fibonacci :");
        System.out.println(text);
        System.out.println("Hasil penjumlahan = "+String.valueOf(total));
    }
}