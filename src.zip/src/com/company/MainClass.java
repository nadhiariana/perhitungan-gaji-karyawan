package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainClass {
    public static void main(String[] args) throws IOException {
        programRamalan();
    }

    public static void programRamalan() throws IOException{
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in));

        System.out.println("Selamat Datang Di Program Ramalan Cupu \n+++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        System.out.println("Data Anda :  \n️♥️♥️♥️♥️♥️♥️");
        System.out.print("Masukkan Nama Anda : ");
        String nama = reader.readLine();
        System.out.print("Masukkan Umur Anda : ");
        String umur  = reader.readLine();
        System.out.println();
        System.out.println();

        System.out.println("Data Pasangan Anda :  \n️♥️♥️♥️♥️♥️♥️♥️♥️♥️");
        System.out.print("Masukkan Nama Pasangan Anda : ");
        String nama_pasangan = reader.readLine();
        System.out.print("Masukkan Umur Pasangan Anda : ");
        String umur_pasangan  = reader.readLine();
        System.out.println();
        System.out.println();

        System.out.print(nama +" "+ "[" +umur+ "] tahun");
        System.out.println();
        System.out.println();
        heartPattern();
        System.out.print(nama_pasangan +" "+ "[" +umur_pasangan+ "] tahun");
        System.out.println();
        System.out.println();
        System.out.print("Tekan ENTER untuk melihat hasil ramalan ... ");
        reader.readLine();
        System.out.print("\nKecocokan anda dengan pasanan anda adalah : " +getNilaiRamalan()+ " %");
        System.out.println();
        System.out.println();
        System.out.print("Terima Kasih karena anda telah menggunakan jasa Ramalan Kami .. ^^v");
    }

    public static double getNilaiRamalan() {
        double pembagi = 1.1;
        int rand = ((int)(Math.random() * (100 - 50)) + 50);
        return roundAvoid(rand/pembagi, 2);
    }

    public static double roundAvoid(double value, int places) {
        double scale = Math.pow(10, places);
        return Math.round(value * scale) / scale;
    }

    public static void heartPattern(){
        final int size = 3  ;

        //loop untuk mencetak bagian atas Hati
        for (int m = 0; m < size; m++) {
            for (int n = 0; n <= 3 * size; n++) {
                double pos1 = Math.sqrt(Math.pow(m - size, 2) + Math.pow(n - size, 2));
                double pos2 = Math.sqrt(Math.pow(m - size, 2) + Math.pow(n - 2 * size, 2));

                if (pos1 < size + 0.5 || pos2 < size + 0.5) {
                    System.out.print("♥️");
                } else {
                    System.out.print("  ");
                }
            }System.out.print(System.lineSeparator());
        }
        //loop untuk mencetak bagian bawah Hati
        for (int m = 1; m <= 2 * size; m++) {
            for (int n = 0; n < m; n++) {
                System.out.print("  ");
            }
            for (int n = 0; n < 3 * size + 1 - 2 * m; n++) {
                System.out.print("♥️");
            }
            System.out.print(System.lineSeparator());
        }
    }
}
