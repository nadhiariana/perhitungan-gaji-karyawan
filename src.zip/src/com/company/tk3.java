package com.company;
import java.util.ArrayList;
import java.util.Scanner;

public class tk3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int nilai, i, totalnilai;
        boolean retry = false;
        String[][] kata =
                {
                        {"die", "diet", "deli", "edit", "idle", "led", "lei", "let", "lid", "lie", "lied", "lit", "lite", "tie", "tied", "tide", "tilde", "tile", "tiled", "tilt", "title", "titled", "tilted"},
                        {"acne", "acnes", "acnes", "can", "cane", "canes", "cense", "case", "cease", "ease", "scene", "sane", "scan", "seen", "sea", "see", "sac", "sec"},
                        {"ern", "hen", "her", "hern", "hero", "heron", "hoke", "honer", "honk", "honker", "horn", "keno", "kern", "krone", "one", "ore", "rho", "roe"}
                };
        String[] tebakan = {"dettli", "secaen", "hkrneo" };
        ArrayList<String> jawaban;
        System.out.println("Coepoe Word Puzzle");
        System.out.println("==================");
        System.out.println("");
        System.out.println("Rules :");
        System.out.println("1. Create a word using given characters, min 3 characters & max 6 characters");
        System.out.println("2. Each level, You have 10 chances to answer correctly.");
        System.out.println("3. To get through to next level, you have to score 70 points each level" );

        do {
            totalnilai = 0;
            for (i = 0; i < 3; i++) {
                jawaban = new ArrayList<>();
                nilai = 0;
                System.out.println("Level " + (i + 1));
                System.out.println("-------------");
                System.out.print("         ");
                for (int j = 0; j < tebakan[i].length(); j++) {
                    System.out.print(tebakan[i].charAt(j) + "        " );
                }
                System.out.println();
                System.out.println();

                for (int j = 0; j < 10; j++) {
                    System.out.print((j + 1) + "> Your Answer : " );
                    String answer = input.next();
                    if (answer.length() < 3 || answer.length() > 6) {
                        j--;
                        continue;
                    }
                    int k;
                    for (k = 0; k < jawaban.size(); k++) {
                        if (answer.equalsIgnoreCase(jawaban.get(k))) {
                            break;
                        }
                    }
                    if (k < jawaban.size()) {
                        System.out.println("You had already type this word before.." );
                        j--;
                        continue;
                    }
                    for (k = 0; k < kata[i].length; k++) {
                        if (answer.equalsIgnoreCase(kata[i][k])) {
                            jawaban.add(answer);
                            nilai += 10;
                            System.out.println("#Right. Score : " + nilai);
                            break;
                        }
                    }
                }
                System.out.println("You had answered 10 times with " + (nilai / 10) + " right answers..");
                System.out.println();
                System.out.println();
                System.out.println("Correct Answers : " );

                for (int j = 0; j < kata[i].length; j++) {
                    System.out.printf("%-8s", kata[i][j]);
                }
                if (nilai < 70) {
                    String ulang;
                    do {
                        System.out.println();
                        System.out.println();
                        System.out.println("You Lose!! Try Again..");
                        System.out.println("Do you want to retry [y/t] ? " );

                        ulang = input.next();
                    } while (!(ulang.equals("y") || ulang.equals("t")));
                    if (ulang.equals("y")) {
                        retry = true;
                    }
                    break;
                }

                totalnilai += nilai;
                System.out.println();
                System.out.println();
                System.out.println();
            }
        } while (i < 3 && retry);
        if (i == 3)
        {
            System.out.println("Overall score : " + totalnilai);
            System.out.println();
            System.out.println("You Win!!");
            System.out.println("Press ENTER to exit");
            input.nextLine();
            input.nextLine();
        }
    }
}

