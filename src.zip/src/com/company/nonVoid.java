package com.company;

public class nonVoid {
    static int jumlahBilangan(int x,int y){
        return x+y;
    }
    public static void main(String[] args){
        int x=5, y=10;
        System.out.print("Jumlah bilangan : "+jumlahBilangan(x,y));
    }
}
