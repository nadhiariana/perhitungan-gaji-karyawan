package com.company;

public class contohFor {
    public static void main (String[] args) {
        for (int i=1;i<=6;i=i+2){
            System.out.println("Nilai : "+i);
        }
    }
}
