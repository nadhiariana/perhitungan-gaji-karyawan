package com.company;

import java.util.Scanner; //meng-import library java.util.Scanner untuk input output

public class Session6 {
    public static void main(String[] args) { //fungsi main program
        setWords();
    }
    public static void setWords(){
        String reverse, hasil; //mendeklarasikan variabel
        Scanner input = new Scanner(System.in); //mendeklarasikan variable scanner untuk menginput huruf
        System.out.print("Masukan Kata : "); //melakukan input string ke variable
        String kata = input.nextLine(); //menangkap inputan kata
        hasil = reverseString(kata);
        if (kata.equals(hasil)){ //mengecek pembalikan dari string
            System.out.println("COOL"); //menampilkan hasil COOL jika hasil sesuai
        }else{
            System.out.println("BAD"); //menampilkan hasil BAD jika hasil tidak sesuai
        }

        System.out.println("Apakah anda ingin mengulang [y/t]");
        String ulang = input.nextLine();
        if(ulang.equalsIgnoreCase("y"))setWords();
    }
    public static String reverseString(String str){
        char ch[]=str.toCharArray();
        String rev="";
        for(int i=ch.length-1;i>=0;i--){
            rev+=ch[i];
        }
        return rev;
    }
}
