package com.company;
import java.util.Scanner;

public class selectionSort {
    static int [] Selection(int[] arr){
        for (int i=0; i<arr.length;i++){
            for (int j=i+1; j<arr.length;j++){
                if(arr[i] > arr[j]){
                    int temp = arr[j];
                    arr[j] = arr[i];
                    arr[i] = temp;
                }
            }
        }return arr;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner (System.in);
        System.out.print("Masukan jumlah element integer = ");
        int angka = scan.nextInt();

        int arra[]= new int [angka];
        for (int x = 0; x < angka;x++){
            System.out.print("Nilai ke-"+(x+1)+" = ");
            arra[x]=scan.nextInt();
        }
        System.out.println("Element integer setelah diurutkan : ");
        Selection(arra);

        for(int r = 0; r < arra.length; r++) {
            System.out.print(arra[r] + "  ");
        }
    }
}
