package com.company;

public class Main{
    public static void main(String[] args) {
        String o = "";
        z:
        for (int x = 0; x < 3; x++){ //looping pertama dilakukan sebanyak 3 kali, menghasilkan x=0,1,2
            for (int y = 0; y < 2; y++){ //looping kedua dilakukan sebanyak 2 kali, menghasilkan y=0,1
                if (x == 1) break; //jika x=1 maka looping berhenti
                if (x == 2 && y == 1) break z; //jika x=2 dan y=1 maka looping berhenti --> hasilnya 20
                //x=0,1,2 dan y=0,1
                //x=0, y=0 --> 00
                //x=0, y=1 --> 01
                //x=2, y=0 --> 20
                o = o + x + y; // o = 00 01 20
            }
        }
        System.out.println(o); //mencetak hasil o
    }
}

