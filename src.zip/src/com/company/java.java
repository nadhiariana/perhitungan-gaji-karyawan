package com.company;
import java.util.Arrays;

class java {
    public static void main (String[] args){
        String [] kota = {"Serang","Tangerang","Palembang","Lombok","Halmahera","Surabaya"};
        Arrays.stream(kota).sorted((s1,s2) -> s2.compareTo(s1)).forEach(System.out::println);
    }
}
